﻿namespace learningapp;

public class Course
{
    public int CourseID;
    public string? CourseName;
    public decimal Rating;    

}
